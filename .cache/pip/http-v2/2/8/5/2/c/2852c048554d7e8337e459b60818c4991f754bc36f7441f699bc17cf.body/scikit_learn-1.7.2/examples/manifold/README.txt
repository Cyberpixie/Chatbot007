.. _manifold_examples:

Manifold learning
-----------------------

Examples concerning the :mod:`sklearn.manifold` module.
