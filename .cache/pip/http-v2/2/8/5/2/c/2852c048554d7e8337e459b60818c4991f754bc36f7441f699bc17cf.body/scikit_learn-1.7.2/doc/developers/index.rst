.. _developers_guide:

=================
Developer's Guide
=================

.. toctree::

   contributing
   minimal_reproducer
   develop
   tips
   utilities
   performance
   cython
   advanced_installation
   bug_triaging
   maintainer
   plotting
